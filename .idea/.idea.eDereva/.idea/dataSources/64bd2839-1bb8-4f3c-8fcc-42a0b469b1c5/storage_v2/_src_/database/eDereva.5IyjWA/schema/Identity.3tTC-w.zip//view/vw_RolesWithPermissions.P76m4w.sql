
        CREATE VIEW [Identity].vw_RolesWithPermissions AS
        SELECT
            R.Id AS RoleId,
            R.Name AS RoleName,
            R.Description AS RoleDescription,
            R.IsDeleted AS RoleIsDeleted,
            P.Id AS PermissionId,
            P.Flags AS PermissionFlags
        FROM [Identity].Roles R
        LEFT JOIN [Identity].Permissions P ON R.Id = P.RoleId
        WHERE R.IsDeleted = 0

        go

