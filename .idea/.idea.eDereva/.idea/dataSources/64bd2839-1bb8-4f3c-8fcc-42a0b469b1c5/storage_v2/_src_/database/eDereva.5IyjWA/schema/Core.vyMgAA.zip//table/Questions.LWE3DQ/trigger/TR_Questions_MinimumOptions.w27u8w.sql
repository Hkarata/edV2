-- Add trigger for checking minimum options per question
CREATE TRIGGER core.TR_Questions_MinimumOptions
    ON core.Questions
    AFTER INSERT, UPDATE
    AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (
        SELECT q.Id
        FROM core.Questions q
        WHERE q.QuestionTypeId IN (1, 2) -- Multiple choice types
          AND (
                  SELECT COUNT(*)
                  FROM core.Options o
                  WHERE o.QuestionId = q.Id
              ) < 4
    )
        BEGIN
            RAISERROR ('Multiple choice questions must have at least 4 options.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END
END;
go

