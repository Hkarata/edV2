
        CREATE VIEW [Identity].vw_UsersWithSoftDelete AS
        SELECT
            U.UserID,
            U.NationalID,
            U.NationalIDType,
            U.FirstName,
            U.MiddleName,
            U.Surname,
            U.Sex,
            U.DateOfBirth,
            DATEDIFF(YEAR, U.DateOfBirth, GETDATE()) -
                CASE
                    WHEN DATEFROMPARTS(YEAR(GETDATE()), MONTH(U.DateOfBirth), DAY(U.DateOfBirth)) > GETDATE()
                    THEN 1
                    ELSE 0
                END AS Age,
            U.Email,
            U.PhoneNumber,
            U.CreatedAt,
            U.UpdatedAt,
            U.DeletedAt,
            U.IsActive
        FROM [Identity].Users U

        go

