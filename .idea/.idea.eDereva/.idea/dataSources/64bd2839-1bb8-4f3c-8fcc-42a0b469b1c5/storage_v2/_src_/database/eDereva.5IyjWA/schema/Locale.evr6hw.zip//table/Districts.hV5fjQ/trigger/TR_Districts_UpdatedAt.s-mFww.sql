
        CREATE TRIGGER locale.TR_Districts_UpdatedAt
        ON locale.Districts
        AFTER UPDATE
        AS
        BEGIN
            SET NOCOUNT ON;
            UPDATE locale.Districts
            SET UpdatedAt = GETUTCDATE()
            FROM locale.Districts D
            INNER JOIN inserted i ON D.Id = i.Id;
        END

        go

