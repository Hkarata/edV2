CREATE PROCEDURE SeedSessions
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @VenueId UNIQUEIDENTIFIER;
    DECLARE @StartTime TIME = '08:00';
    DECLARE @EndTime TIME = '20:00';
    DECLARE @CurrentStartTime TIME;
    DECLARE @Date DATE = DATEADD(WEEK, 1, CAST(GETDATE() AS DATE)); -- Next week's date

    -- Cursor to iterate through all venues
    DECLARE VenueCursor CURSOR FOR
        SELECT Id
        FROM Core.Venues
        WHERE IsDeleted = 0; -- Exclude deleted venues

    OPEN VenueCursor;
    FETCH NEXT FROM VenueCursor INTO @VenueId;

    WHILE @@FETCH_STATUS = 0
        BEGIN
            SET @CurrentStartTime = @StartTime;

            -- Loop to create sessions for the day
            WHILE @CurrentStartTime < @EndTime
                BEGIN
                    INSERT INTO Core.Sessions (Id, Date, Status, StartTime, EndTime, Capacity, IsDeleted, VenueId)
                    VALUES (
                               NEWID(),
                               @Date,
                               1, -- Default status
                               @CurrentStartTime,
                               DATEADD(HOUR, 2, @CurrentStartTime), -- Add 2 hours for the end time
                               0, -- Default capacity, adjust as needed
                               0,
                               @VenueId
                           );

                    -- Increment the start time by 3 hours (2 hours session + 1 hour interval)
                    SET @CurrentStartTime = DATEADD(HOUR, 3, @CurrentStartTime);
                END;

            FETCH NEXT FROM VenueCursor INTO @VenueId;
        END;

    CLOSE VenueCursor;
    DEALLOCATE VenueCursor;
END;
go

