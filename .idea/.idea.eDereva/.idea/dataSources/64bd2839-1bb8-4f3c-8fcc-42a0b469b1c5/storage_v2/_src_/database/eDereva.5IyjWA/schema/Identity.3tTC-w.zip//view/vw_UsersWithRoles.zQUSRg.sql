
        CREATE VIEW [Identity].vw_UsersWithRoles AS
        SELECT
            U.UserID,
            U.NationalID,
            U.FirstName,
            U.MiddleName,
            U.Surname,
            U.Sex,
            U.DateOfBirth,
            DATEDIFF(YEAR, U.DateOfBirth, GETDATE()) -
                CASE
                    WHEN DATEFROMPARTS(YEAR(GETDATE()), MONTH(U.DateOfBirth), DAY(U.DateOfBirth)) > GETDATE()
                    THEN 1
                    ELSE 0
                END AS Age,
            U.Email,
            U.PhoneNumber,
            U.CreatedAt,
            U.UpdatedAt,
            U.DeletedAt,
            U.IsActive,
            RU.RoleId,
            R.Name AS RoleName
        FROM [Identity].Users U
        INNER JOIN [Identity].RoleUser RU ON U.UserID = RU.UserId
        INNER JOIN [Identity].Roles R ON RU.RoleId = R.Id
        WHERE U.DeletedAt IS NULL
        AND R.IsDeleted = 0

        go

