
        CREATE VIEW [Identity].vw_UsersWithLicenseClasses AS
        SELECT
            U.UserID,
            U.FirstName,
            U.MiddleName,
            U.Surname,
            U.DateOfBirth,
            DATEDIFF(YEAR, U.DateOfBirth, GETDATE()) -
                CASE
                    WHEN DATEFROMPARTS(YEAR(GETDATE()), MONTH(U.DateOfBirth), DAY(U.DateOfBirth)) > GETDATE()
                    THEN 1
                    ELSE 0
                END AS Age,
            LC.ClassName AS LicenseClassName,
            ULC.AssignedAt AS LicenseClassAssignedAt
        FROM [Identity].Users U
        INNER JOIN [Identity].UserLicenseClasses ULC ON U.UserID = ULC.UserID
        INNER JOIN [Identity].LicenseClasses LC ON ULC.LicenseClassID = LC.LicenseClassID
        WHERE U.DeletedAt IS NULL

        go

