
        CREATE TRIGGER locale.TR_Regions_UpdatedAt
        ON locale.Regions
        AFTER UPDATE
        AS
        BEGIN
            SET NOCOUNT ON;
            UPDATE locale.Regions
            SET UpdatedAt = GETUTCDATE()
            FROM locale.Regions R
            INNER JOIN inserted i ON R.Id = i.Id;
        END

        go

