-- Add triggers for maintaining referential integrity
CREATE TRIGGER core.TR_TestSections_QuestionCount
    ON core.TestSections
    AFTER INSERT, UPDATE
    AS
BEGIN
    SET NOCOUNT ON;

    -- Verify total questions in test sections matches test total
    IF EXISTS (
        SELECT t.Id, t.TotalQuestions, SUM(ts.QuestionCount) as SectionTotal
        FROM core.Tests t
                 JOIN core.TestSections ts ON t.Id = ts.TestId
        GROUP BY t.Id, t.TotalQuestions
        HAVING t.TotalQuestions != SUM(ts.QuestionCount)
    )
        BEGIN
            RAISERROR ('Total questions in sections must match test total questions.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END
END;
go

