CREATE TRIGGER trg_UpdateTimestamp
            ON [Identity].Users
            AFTER UPDATE
            AS
        BEGIN
            SET NOCOUNT ON;
            UPDATE [Identity].Users
            SET UpdatedAt = GETDATE()
            WHERE UserID IN (SELECT DISTINCT UserID FROM Inserted);
        END;
go

